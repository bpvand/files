MSXTEST: APPLY THE MULTISCALE COEFFICIENT TEST TO YOUR DATA

Requires MATLAB R2022b or newer. Optional clustering uses Statistics and
Machine Learning Toolbox; the test itself needs only base MATLAB.
No parallel pool or downloaded data needed.
Unzip, open the msxtest_matlab folder in MATLAB, and run:

    result = example_msxtest;

This uses synthetic outcomes for four units and two common regressors. It saves example input
CSVs, test results and plots in a new msxtest_results/run_* folder. The example
also saves coefficients_and_rejection_periods.png (and an editable .fig):
Unit B is highlighted in red, other units in blue, with rejection periods
below, following the empirical application's display convention.
An example preview is included as example_figure.png.
The clustering preview is example_clusters.png.
The example enables clustering. Set o.clustering.enabled=false in the example
to run without Statistics and Machine Learning Toolbox.

YOUR DATA

Edit run_my_data.m, or call directly:

    Y = readmatrix('outcomes.csv');
    X = readmatrix('regressors.csv');
    o = msxtest_options();
    result = msxtest(Y,X,o);

Y has T rows (observations) and N columns (units). Common regressors X
have T rows and K columns. For unit-specific regressors use a T-by-K-by-N array:
X(:,:,i) contains the regressors for unit i. N must be at least 2.

Supply numeric, finite, complete data, aligned in chronological row order.
Remove headers/date columns before passing numeric arrays. There is no
automatic date matching, missing-value removal, transformations, scaling,
or differencing. Bandwidths refer to observation time, not calendar duration.

Optional labels and dates:
    o.unitNames = ["Unit A","Unit B","Unit C"];
    o.regressorNames = ["Regressor 1","Regressor 2"];
    o.time = dates;                 % T increasing datetimes or numeric values

The null is equality of ALL K coefficient paths across units over the tested
intervals. No intercept column is added. By default each outcome is demeaned
over time; X is not demeaned. Set o.demeanY=false to disable this step. To
compare a time-varying intercept, include a column of ones in X and disable
demeaning. All units must use the same regressor definitions and ordering.

OPTIONS

Start with o=msxtest_options(), then change only what you need:

    o.alpha = 0.05;
    o.gaussianDraws = 4999;
    o.seed = 123;
    o.outputDirectory = 'my_results';
    o.makePlots = true;

Default grid: minimum h=T^(-1/3), maximum h=1/4, u=5t/T, h=(5s-3)/T.
Only intervals [u-h,u+h] contained in [0,1] are tested. Options include:

    o.grid.mode = 'kv';             % minimum h=log(T)/T; default is 'paper'
    o.grid.latticeMode = 'full';    % u=t/T, h=s/T; can be much larger
    o.grid.minimumBandwidth = 0.08; % optional numeric override
    o.grid.maximumBandwidth = 0.20;

Other lattices: 'paper-empirical' (default), 'kv-2020', 'kv-quarterly'.
For your own spacing in observation-index units:

    o.grid.latticeMode = 'custom';
    o.grid.locationStep = 10;  o.grid.locationOffset = 0;
    o.grid.bandwidthStep = 10; o.grid.bandwidthOffset = 0;

Or supply exact locations/bandwidths, expressed as fractions of sample length:

    o.grid.locations = (0.1:0.05:0.9)';
    o.grid.bandwidths = [0.05 0.10 0.20]';

Explicit bandwidths replace the minimum/maximum bandwidth rules. Changing a
grid changes the jointly tested family and its simulated critical value.
Very small windows can give singular designs; use wider windows in that case.
Use sparse grids for large panels. Runs requiring over 1 GB for the local
statistic array alone are stopped before allocation.

HAC defaults: separate Bartlett estimates, Andrews AR(1) lag bandwidth,
leave-one-out pilot residuals, pilot coefficient bandwidth min(test h).

    o.hac.scoreMode = 'pilot-in-sample';  % alternative to 'pilot-loo'
    o.hac.bandwidthMode = 'fixed';
    o.hac.fixedBandwidth = 5;            % HAC lag bandwidth, in observations
    o.hac.pilotBandwidthMode = 'fixed';
    o.hac.pilotBandwidth = 0.10;          % coefficient bandwidth, in [0,1]

Other lag rule: 't-one-third'. Other pilot rules: 'smallest-grid',
'largest-grid', 't-one-third', 't-one-fifth'. o.hac.poolHomogeneous=true
pools score covariance estimates; the default is false.

CLUSTERING

    o.clustering.enabled = true;
    o.clustering.fixedGroups = 2;

This uses the same complete-linkage routine as the simulations. Distances are
the continuous pairwise maxima max_(u,h){S_ij(u,h)-lambda(h)}, not binary
rejection indicators. The estimated group count is the smallest K along the
hierarchy for which every within-group distance is at most the global critical
value. The fixed-K partition is returned separately for comparison (the paper's
application uses K=2); it does not determine the estimated count. All K
regressor coefficients share one partition. Group numbers are arbitrary labels.

result.clusters contains both memberships. result.clustering contains the
estimated count, linkage and distances. Enabled runs save cluster_memberships.csv,
clustering_summary.csv and, when makePlots=true, a dendrogram and coefficient
paths colored by cluster. Both estimated and fixed partitions use complete
linkage. Negative distances are shifted only for linkage computation/display;
the stopping rule uses the original distances and cutoff.
Tied merge heights can yield fewer than the requested fixed groups in MATLAB;
result.clustering.actualFixedGroups records the number returned.

RESULTS

result.global       Global statistic, critical value, simulated p-value,
                    and rejection decision at o.alpha.
result.pairs        Pairwise maxima and decisions using the GLOBAL cutoff.
result.intervals    Every rejected pair/interval, with row and time endpoints.
result.coefficients Coefficient paths at the smallest test bandwidth.

These four tables are saved as CSV, together with results.mat and PNG plots.
Each call creates a new run_* subfolder. Set o.outputDirectory='' to return
results without writing files or plots. All bandwidth-specific coefficient
estimates are in result.coefficientEstimates (N-by-location-by-K-by-h).
Set o.storeLocalStatistics=true to retain the full N-by-N-by-location-by-h
statistic array; inadmissible intervals and diagonal pairs are -Inf.
Options, Gaussian reference draws, grid and covariance diagnostics are saved.
P-values use (1 + reference draws >= statistic)/(B+1); rejection uses the
simulated (1-alpha) quantile. Small discrepancies at the cutoff can arise.
Overlapping rejected intervals are not merged. Endpoint rows include kernel
support boundaries, where the Epanechnikov kernel has zero weight. Dates are
labels for the supplied rows. Coefficient plots do not include confidence bands.

For the combined coefficient/rejection figure on your own results:
    [fig,periods] = plot_msxtest_diagnostics(result,'Unit B');
    close(fig);
Use a unit name or index; omit it to show all units and pairwise comparisons.
The figure and rejection_periods.csv are saved in the result folder. Black
bars mark grid centers with at least one rejected bandwidth, not the entire
support of rejected windows; grey marks untested centers. Rejections are
joint across all coefficients. Paths use the smallest bandwidth, restricted
to its admissible centers. By default the 18 largest pair statistics are
shown; supply a third argument to change this limit. The periods table refers
to the displayed pairs and joins consecutive rejected grid centers only.

SCOPE

This is the original test. Gaussian calibration follows the paper's independent
errors across units and common long-run score covariance assumptions.
Unit-specific X additionally requires the paper's design condition (A9);
arbitrary iid individual regressors are not generally covered. HAC allows
the specified within-unit temporal dependence; it does not establish these
other assumptions from the data. All K coefficients are tested jointly.

The main function is msxtest.m; defaults are in msxtest_options.m. Keep the
private folder beside them. The code uses Epanechnikov kernels, the paper's
infinity-norm statistic and multiscale penalty, and Y-only demeaning when
enabled. It is adapted from the authors' MATLAB replication implementation.
