% Change the two filenames and any options, then run this script.
Y = readmatrix('outcomes.csv');
X = readmatrix('regressors.csv');
options = msxtest_options();
result = msxtest(Y,X,options);
