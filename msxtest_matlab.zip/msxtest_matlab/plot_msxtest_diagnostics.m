function [fig,periods] = plot_msxtest_diagnostics(result,focusUnit,maximumPairs)
% Coefficient paths and joint rejection centers; optionally focus on one unit.
if nargin<2, focusUnit = []; end
if nargin<3, maximumPairs = 18; end
validateattributes(maximumPairs,{'numeric'},{'scalar','integer','positive'});
units = unique(result.coefficients.Unit,'stable');
regressors = unique(result.coefficients.Regressor,'stable');
u = result.grid.locations(:);
T = numel(result.time); K = numel(regressors);
focus = [];
if ~isempty(focusUnit)
    if isnumeric(focusUnit)
        validateattributes(focusUnit,{'numeric'},{'scalar','integer','>=',1,'<=',numel(units)});
        focus = focusUnit;
    else
        focus = find(units==string(focusUnit));
        assert(isscalar(focus),'msxtest:Focus','Choose an existing unit name or index.');
    end
end
pairs = result.pairs;
if ~isempty(focus)
    pairs = pairs(pairs.UnitI==units(focus) | pairs.UnitJ==units(focus),:);
end
totalPairs = height(pairs);
pairs = pairs(1:min(maximumPairs,totalPairs),:);
rows = height(pairs);
if numel(u)==1
    edges = [max(0,u-0.5/T);min(1,u+0.5/T)];
else
    edges = [max(0,u(1)-(u(2)-u(1))/2);(u(1:end-1)+u(2:end))/2; ...
        min(1,u(end)+(u(end)-u(end-1))/2)];
end
periods = table('Size',[0,5],'VariableTypes', ...
    {'string','string','double','double','double'},'VariableNames', ...
    {'UnitI','UnitJ','FirstRejectedU','LastRejectedU','PeakStatistic'});
fig = figure('Visible','off','Color','w','Position', ...
    [100,100,1150,max(850,(K+1)*max(230,25*rows))]);
layout = tiledlayout(fig,K+1,1,'TileSpacing','compact','Padding','compact');
axesList = gobjects(K+1,1);
valid = result.grid.admissible(:,1);
for k=1:K
    ax = nexttile(layout); axesList(k) = ax; hold(ax,'on');
    beta = reshape(result.coefficientEstimates(:,:,k,1),numel(units),numel(u))';
    beta(~valid,:) = NaN;
    if isempty(focus)
        linesPlot = plot(ax,u,beta,'LineWidth',1.3);
        if numel(units)<=12
            legend(ax,linesPlot,units,'Location','best','Interpreter','none');
        end
    else
        others = setdiff(1:numel(units),focus,'stable');
        otherLines = plot(ax,u,beta(:,others),'Color',[.15,.40,.70],'LineWidth',.8);
        focusLine = plot(ax,u,beta(:,focus),'Color',[.75,0,0],'LineWidth',1.8);
        legend(ax,[focusLine;otherLines(1)], ...
            [units(focus);"Other units"],'Location','best','Interpreter','none');
    end
    title(ax,regressors(k)+sprintf(' (h = %.3f)',result.grid.bandwidths(1)), ...
        'Interpreter','none','FontWeight','normal');
    ylabel(ax,'Estimated coefficient');
    style_time_axis(ax,result.time,T);
    grid(ax,'on'); ax.GridAlpha = .12;
end
ax = nexttile(layout); axesList(end) = ax; hold(ax,'on');
patch(ax,[0,1,1,0],[.5,.5,rows+.5,rows+.5],[.93,.93,.93],'EdgeColor','none');
tested = any(result.grid.admissible,2);
for r=1:rows
    draw_runs(ax,tested,edges,r,.5,[1,1,1]);
    selected = result.intervals(result.intervals.UnitI==pairs.UnitI(r) & ...
        result.intervals.UnitJ==pairs.UnitJ(r),:);
    reject = ismember(u,selected.u);
    draw_runs(ax,reject,edges,r,.29,[.12,.12,.12]);
    [first,last] = runs(reject);
    for p=1:numel(first)
        mask = selected.u>=u(first(p)) & selected.u<=u(last(p));
        periods = [periods;table(pairs.UnitI(r),pairs.UnitJ(r),u(first(p)),u(last(p)), ...
            max(selected.Statistic(mask)),'VariableNames',periods.Properties.VariableNames)]; %#ok<AGROW>
    end
end
rowLabels = pairs.UnitI+" / "+pairs.UnitJ;
if ~isempty(focus)
    rowLabels = pairs.UnitJ;
    mask = rowLabels==units(focus); rowLabels(mask) = pairs.UnitI(mask);
end
style_time_axis(ax,result.time,T);
set(ax,'YDir','reverse','YTick',1:rows,'YTickLabel',rowLabels,'TickLabelInterpreter','none');
ylim(ax,[.5,rows+.5]);
title(ax,'Joint rejection periods (all coefficients; any tested bandwidth)','FontWeight','normal');
description = "Black = rejected grid centers; grey = outside the test grid";
if totalPairs>rows
    description = description+sprintf('; %d largest pair statistics of %d',rows,totalPairs);
end
subtitle(ax,description,'FontWeight','normal');
xlabel(ax,'Time');
linkaxes(axesList,'x'); xlim(ax,[0,1]);
heading = "Estimated coefficients and pairwise rejection periods";
if ~isempty(focus), heading = units(focus)+": estimated coefficients and rejection periods"; end
sgtitle(layout,heading,'Interpreter','none','FontWeight','normal');
periods.FirstRejectedTime = result.time(max(1,min(T,round(T*periods.FirstRejectedU))));
periods.LastRejectedTime = result.time(max(1,min(T,round(T*periods.LastRejectedU))));
if ~isempty(result.outputDirectory)
    base = fullfile(result.outputDirectory,'coefficients_and_rejection_periods');
    exportgraphics(fig,[base '.png'],'Resolution',160);
    savefig(fig,[base '.fig']);
    writetable(periods,fullfile(result.outputDirectory,'rejection_periods.csv'));
end
end

function draw_runs(ax,mask,edges,row,half,color)
[first,last] = runs(mask);
for p=1:numel(first)
    bounds = [edges(first(p)),edges(last(p)+1)];
    patch(ax,bounds([1,2,2,1]),row+[-half,-half,half,half],color,'EdgeColor','none');
end
end

function [first,last] = runs(mask)
changes = diff([false,reshape(mask,1,[]),false]);
first = find(changes==1); last = find(changes==-1)-1;
end

function style_time_axis(ax,time,T)
indices = unique(round(linspace(1,T,6)));
if isdatetime(time), labels = string(time(indices),'dd-MMM-yyyy');
else, labels = compose('%.6g',time(indices)); end
set(ax,'XTick',indices/T,'XTickLabel',labels,'TickDir','out', ...
    'FontSize',10,'Box','off','Layer','top','TickLabelInterpreter','none');
xlim(ax,[0,1]);
end
