function result = msxtest(Y,X,options)
% MSXTEST Compare time-varying coefficient paths across units.
% Y: T-by-N. X: T-by-K (common) or T-by-K-by-N (individual).
if nargin<3, options = struct(); end
o = merge_options(msxtest_options(),options,'options');
validateattributes(Y,{'numeric'},{'2d','real','finite','nonempty'});
validateattributes(X,{'numeric'},{'real','finite','nonempty'});
Y = double(Y); X = double(X);
[T,N] = size(Y);
K = size(X,2);
assert(N>=2 && T>=5 && size(X,1)==T && ndims(X)<=3 && ...
    (size(X,3)==1 || size(X,3)==N),'msxtest:Dimensions', ...
    'Use Y=T-by-N with N>=2 and X=T-by-K or T-by-K-by-N, on the same rows.');
assert(K<T,'msxtest:Dimensions','Use fewer regressors than observations.');
validate_options(o);
if o.clustering.enabled
    validateattributes(o.clustering.fixedGroups,{'numeric'}, ...
        {'scalar','integer','>=',1,'<=',N});
    assert(exist('linkage','file')==2 && license('test','Statistics_Toolbox'), ...
        'msxtest:ClusteringToolbox','Clustering requires Statistics and Machine Learning Toolbox.');
end
units = labels(o.unitNames,N,'Unit');
regressors = labels(o.regressorNames,K,'X');
time = o.time(:);
if isempty(time), time = (1:T)'; end
assert((isnumeric(time) || isdatetime(time)) && numel(time)==T && ...
    all(~ismissing(time)) && issorted(time,'strictascend'), ...
    'msxtest:Time','time must contain T increasing numeric values or dates.');
if isnumeric(time), assert(all(isfinite(time)),'msxtest:Time','Time values must be finite.'); end
[u,h,grid] = msxtest_grid(T,o.grid);
estimatedMB = 8*N*N*numel(u)*numel(h)/1024^2;
assert(estimatedMB<1024,'msxtest:GridMemory', ...
    'Local statistics alone would exceed 1 GB. Use a coarser grid or fewer units.');
if size(X,3)==1
    panelX = repmat(reshape(X,[1,T,K]),[N,1,1]);
else
    panelX = permute(X,[3,1,2]);
end
panelY = Y';
if o.demeanY, panelY = panelY-mean(panelY,2); end
before = rng;
restoreRNG = onCleanup(@() rng(before));
rng(o.seed,'twister');
pre = precompute_paper_msxtest_quantities(panelY,panelX,h,u,o.hac);
for i=1:N-1
    for j=i+1:N
        local = reshape(pre.mS(i,j,:,:),[numel(u),numel(h)]);
        assert(all(isfinite(local(grid.admissible))),'msxtest:SingularDesign', ...
            'A tested local design is singular. Widen bandwidths or remove collinear regressors.');
    end
end
[gaussian,critical] = gaussian_bootstrap_multiscale(panelY,panelX,h,u, ...
    o.gaussianDraws,o.alpha,pre,grid.admissible);
statistic = max(pre.mS(:));
tail = (1+nnz(gaussian>=statistic))/(o.gaussianDraws+1);
result.global = table(N,T,K,statistic,critical,tail,statistic>critical,o.alpha,o.gaussianDraws, ...
    'VariableNames',{'N','T','K','Statistic','CriticalValue','PValue','Reject','Alpha','GaussianDraws'});
[result.pairs,result.intervals] = summarize_local(pre,critical,units,time);
beta = nan(N,numel(u),K,numel(h));
for ih=1:numel(h)
    for i=1:N, beta(i,:,:,ih) = reshape(pre.mBeta_all{i,ih},[1,numel(u),K]); end
end
result.coefficientEstimates = beta;
result.coefficients = coefficient_table(beta,u,h,units,regressors,time);
[designMaximum,designInfo] = compute_a12_design_diagnostic(pre);
result.diagnostics = pre.sHACDiagnostics;
result.diagnostics.designMaximum = designMaximum;
result.diagnostics.scaledDesignMaximum = designInfo.scaledMaximum;
result.covariances = pre.mSigma_all;
result.gaussianStatistics = gaussian;
result.grid = grid;
result.options = o;
result.time = time;
result.clustering = struct();
result.clusters = table();
if o.clustering.enabled
    c = cluster_msxtest_statistics(pre.mS,critical,o.clustering.fixedGroups,N);
    result.clusters = table(units,c.vEstimatedCluster,c.vFixedCluster, ...
        'VariableNames',{'Unit','EstimatedCluster','FixedCluster'});
    result.clustering = struct('estimatedGroups',c.iEstimatedGroups, ...
        'fixedGroups',c.iFixedGroups,'actualFixedGroups',numel(unique(c.vFixedCluster)), ...
        'criticalValue',critical, ...
        'dissimilarity',c.mDissimilarity,'linkage',c.Z,'linkageShift',c.dLinkageShift);
end
result.localStatistics = [];
if o.storeLocalStatistics, result.localStatistics = pre.mS; end
result.outputDirectory = '';
if strlength(string(o.outputDirectory))>0
    directory = fullfile(char(o.outputDirectory), ...
        ['run_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
    while isfolder(directory), directory = [directory '_1']; end %#ok<AGROW>
    mkdir(directory);
    result.outputDirectory = directory;
    writetable(result.global,fullfile(directory,'global_test.csv'));
    writetable(result.pairs,fullfile(directory,'pairwise_tests.csv'));
    writetable(result.intervals,fullfile(directory,'rejected_intervals.csv'));
    writetable(result.coefficients,fullfile(directory,'coefficients.csv'));
    if o.clustering.enabled
        writetable(result.clusters,fullfile(directory,'cluster_memberships.csv'));
        clusteringSummary = table(result.clustering.estimatedGroups,result.clustering.fixedGroups, ...
            result.clustering.actualFixedGroups,critical, ...
            'VariableNames',{'EstimatedGroups','RequestedFixedGroups','ActualFixedGroups','CriticalValue'});
        writetable(clusteringSummary,fullfile(directory,'clustering_summary.csv'));
    end
    save(fullfile(directory,'results.mat'),'result','-v7.3');
    if o.makePlots, save_plots(result,units,regressors,directory); end
    if o.makePlots && o.clustering.enabled
        plot_msxtest_clusters(result,units,regressors,directory);
    end
end
disp(result.global);
if ~isempty(result.outputDirectory), fprintf('Results: %s\n',result.outputDirectory); end
end

function out = merge_options(out,in,prefix)
assert(isstruct(in) && isscalar(in),'msxtest:Options','Options must be a scalar structure.');
fields = fieldnames(in);
for i=1:numel(fields)
    field = fields{i};
    assert(isfield(out,field),'msxtest:Options','Unknown option: %s.%s',prefix,field);
    if isstruct(out.(field))
        out.(field) = merge_options(out.(field),in.(field),[prefix '.' field]);
    else
        out.(field) = in.(field);
    end
end
end

function validate_options(o)
validateattributes(o.alpha,{'numeric'},{'scalar','real','finite','>',0,'<',1});
validateattributes(o.gaussianDraws,{'numeric'},{'scalar','integer','finite','>=',20});
validateattributes(o.seed,{'numeric'},{'scalar','integer','finite','>=',0,'<',2^32});
for value = {o.demeanY,o.makePlots,o.storeLocalStatistics,o.hac.poolHomogeneous, ...
        o.hac.finiteSampleCorrection,o.clustering.enabled}
    assert(islogical(value{1}) && isscalar(value{1}),'msxtest:Options','Switches must be true or false.');
end
assert((ischar(o.outputDirectory) && isrow(o.outputDirectory)) || ...
    (isstring(o.outputDirectory) && isscalar(o.outputDirectory)) || isempty(o.outputDirectory), ...
    'msxtest:Options','outputDirectory must be a folder name or empty.');
assert(ismember(lower(string(o.hac.scoreMode)),["pilot-loo","pilot-in-sample"]), ...
    'msxtest:Options','hac.scoreMode must be pilot-loo or pilot-in-sample.');
assert(ismember(lower(string(o.hac.bandwidthMode)),["andrews-ar1","t-one-third","fixed"]), ...
    'msxtest:Options','Unknown hac.bandwidthMode.');
assert(ismember(lower(string(o.hac.pilotBandwidthMode)), ...
    ["smallest-grid","largest-grid","t-one-third","t-one-fifth","fixed"]), ...
    'msxtest:Options','Unknown hac.pilotBandwidthMode.');
validateattributes(o.hac.minimumLOODenominator,{'numeric'},{'scalar','real','finite','>',0,'<=',1});
validateattributes(o.hac.commonRegressorTolerance,{'numeric'},{'scalar','real','finite','>=',0});
if strcmpi(o.hac.bandwidthMode,'fixed')
    validateattributes(o.hac.fixedBandwidth,{'numeric'},{'scalar','real','finite','>',0});
end
if strcmpi(o.hac.pilotBandwidthMode,'fixed')
    validateattributes(o.hac.pilotBandwidth,{'numeric'},{'scalar','real','finite','>',0,'<=',1});
end
end

function names = labels(names,count,prefix)
if isempty(names), names = prefix+string((1:count)'); else, names = string(names(:)); end
assert(numel(names)==count && all(~ismissing(names)) && all(strlength(names)>0) && ...
    numel(unique(names))==count,'msxtest:Labels','Provide a unique, nonempty name for every %s.',prefix);
end

function [pairs,intervals] = summarize_local(pre,critical,units,time)
pairs = table();
intervals = table('Size',[0,9],'VariableTypes', ...
    {'string','string','double','double','double','double','double','double','double'}, ...
    'VariableNames',{'UnitI','UnitJ','u','h','FirstRow','LastRow','Statistic','PairI','PairJ'});
for i=1:pre.N-1
    for j=i+1:pre.N
        local = reshape(pre.mS(i,j,:,:),[pre.M,pre.nH]);
        [maximum,index] = max(local(:));
        [iu,ih] = ind2sub(size(local),index);
        pairs = [pairs;table(units(i),units(j),maximum,maximum>critical,pre.vU(iu),pre.vH(ih), ...
            'VariableNames',{'UnitI','UnitJ','Statistic','Reject','u','h'})]; %#ok<AGROW>
        mask = local>critical & pre.mAdmissible;
        [iu,ih] = find(mask);
        count = numel(iu);
        if count==0, continue; end
        u = pre.vU(iu); h = pre.vH(ih);
        first = max(1,ceil(pre.T*(u-h)-1e-9));
        last = min(pre.T,floor(pre.T*(u+h)+1e-9));
        intervals = [intervals;table(repmat(units(i),count,1),repmat(units(j),count,1),u,h, ...
            first,last,local(mask),repmat(i,count,1),repmat(j,count,1), ...
            'VariableNames',intervals.Properties.VariableNames)]; %#ok<AGROW>
    end
end
intervals.StartTime = time(intervals.FirstRow);
intervals.EndTime = time(intervals.LastRow);
pairs = sortrows(pairs,'Statistic','descend');
end

function paths = coefficient_table(beta,u,h,units,regressors,time)
[N,M,K,~] = size(beta);
count = N*M*K;
names = strings(count,1); regressorLabels = names; value = nan(count,1); location = value;
row = 0;
for i=1:N
    for k=1:K
        rows = row+(1:M);
        names(rows) = units(i); regressorLabels(rows) = regressors(k);
        location(rows) = u; value(rows) = reshape(beta(i,:,k,1),[],1);
        row = row+M;
    end
end
paths = table(names,regressorLabels,location,repmat(h(1),count,1),value, ...
    'VariableNames',{'Unit','Regressor','u','h','Beta'});
paths.Time = time(max(1,min(numel(time),round(numel(time)*location))));
end

function save_plots(result,units,regressors,directory)
fig = figure('Visible','off','Color','w','Position',[100,100,1100,400*numel(regressors)]);
closer = onCleanup(@() close(fig));
tiledlayout(numel(regressors),1,'TileSpacing','compact');
for k=1:numel(regressors)
    nexttile; hold on;
    for i=1:numel(units)
        path = result.coefficients(result.coefficients.Unit==units(i) & ...
            result.coefficients.Regressor==regressors(k),:);
        plot(path.Time,path.Beta,'LineWidth',1.2,'DisplayName',units(i));
    end
    title(regressors(k),'Interpreter','none'); ylabel('Coefficient'); grid on;
    if numel(units)<=12, legend('Location','best','Interpreter','none'); end
end
xlabel('Time');
exportgraphics(fig,fullfile(directory,'coefficient_paths.png'),'Resolution',160);
fig2 = figure('Visible','off','Color','w','Position',[100,100,850,700]);
closer2 = onCleanup(@() close(fig2));
matrix = nan(numel(units));
for r=1:height(result.pairs)
    i = find(units==result.pairs.UnitI(r)); j = find(units==result.pairs.UnitJ(r));
    matrix(i,j) = result.pairs.Reject(r); matrix(j,i) = matrix(i,j);
end
heatmap(units,units,matrix,'ColorLimits',[0,1],'Colormap',[.96,.96,.96;.75,.15,.1], ...
    'MissingDataLabel','Same unit','CellLabelFormat','%d','Title','Pairwise rejection (global critical value)');
exportgraphics(fig2,fullfile(directory,'pairwise_rejections.png'),'Resolution',160);
end
