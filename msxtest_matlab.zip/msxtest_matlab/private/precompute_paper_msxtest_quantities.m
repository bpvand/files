function sPre = precompute_paper_msxtest_quantities(mY, mX, vH, vU, sHAC)

if nargin < 5 || isempty(sHAC)
    sHAC = struct();
end

[N, T, K] = size(mX);
vH = vH(:);
vU = vU(:);
M = length(vU);
nH = length(vH);
vTime = (1:T)' / T;
vLambda = sqrt(2 * log(1 ./ (2 * vH)));
mYDemeaned = mY;

sPre.N = N;
sPre.T = T;
sPre.K = K;
sPre.M = M;
sPre.nH = nH;
sPre.vH = vH;
sPre.vU = vU;
sPre.mAdmissible = vU >= vH' & vU <= (1 - vH');
sPre.mYDemeaned = mYDemeaned;
sPre.mBeta_all = cell(N, nH);
sPre.mMDesign_all = cell(N, nH);
sPre.mSigma_all = cell(N, nH);
sPre.mHACBandwidth = nan(N, nH);
sPre.mDelta_all = cell(N, N, nH);
sPre.cKernelRaw = cell(nH, 1);
sPre.mS = -inf(N, N, M, nH);

if ~isfield(sHAC, 'scoreMode') || isempty(sHAC.scoreMode)
    sHAC.scoreMode = 'pilot-in-sample';
end

for ih = 1:nH
    dH = vH(ih);
    mKernelRaw = epanechnikov_kernel((vTime - vU') / dH);
    sPre.cKernelRaw{ih} = mKernelRaw;

    for i = 1:N
        mX_i = reshape(mX(i, :, :), [T, K]);
        vY_i = mYDemeaned(i, :)';
        mBeta_i = nan(M, K);
        mMDesign_i = nan(M, K, K);

        for m = 1:M
            vWeight = mKernelRaw(:, m);
            mCrossProduct = mX_i' * (mX_i .* vWeight);
            if rcond(mCrossProduct) < 1e-12
                continue;
            end
            mBeta_i(m, :) = (mCrossProduct \ (mX_i' * (vWeight .* vY_i)))';
            mMDesign_i(m, :, :) = reshape(mCrossProduct / (T * dH), [1, K, K]);
        end

        sPre.mBeta_all{i, ih} = mBeta_i;
        sPre.mMDesign_all{i, ih} = mMDesign_i;
    end
end

if strcmpi(sHAC.scoreMode, 'legacy-in-sample')
    for ih = 1:nH
        for i = 1:N
            mX_i = reshape(mX(i, :, :), [T, K]);
            vY_i = mYDemeaned(i, :)';
            mBeta_i = sPre.mBeta_all{i, ih};
            mBetaAtTime = interpolate_beta_path(vU, mBeta_i, vTime);
            vResidual = vY_i - sum(mX_i .* mBetaAtTime, 2);
            [mSigma_i, dHACBandwidth] = ...
                estimate_bartlett_hac(mX_i .* vResidual, sHAC);
            sPre.mSigma_all{i, ih} = mSigma_i;
            sPre.mHACBandwidth(i, ih) = dHACBandwidth;
        end
    end
    sPre.sHACDiagnostics = summarize_legacy_hac(sPre.mSigma_all, ...
        sPre.mHACBandwidth, sHAC.scoreMode);
else
    if regressors_are_common(mX, sHAC)
        [aSigma, sPre.mHACBandwidth, sPre.sHACDiagnostics] = ...
            estimate_common_regressor_hac(mYDemeaned, mX, vH, sHAC);
    else
        [aSigma, sPre.mHACBandwidth, sPre.sHACDiagnostics] = ...
            estimate_individual_regressor_hac(mYDemeaned, mX, vH, sHAC);
    end
    for ih = 1:nH
        for i = 1:N
            sPre.mSigma_all{i, ih} = reshape(aSigma(i, :, :, ih), [K, K]);
        end
    end
end

for ih = 1:nH
    dH = vH(ih);
    vValidLocations = find(sPre.mAdmissible(:, ih));
    for i = 1:N - 1
        mBeta_i = sPre.mBeta_all{i, ih};
        mM_i = sPre.mMDesign_all{i, ih};
        mSigma_i = sPre.mSigma_all{i, ih};
        for j = i + 1:N
            mBeta_j = sPre.mBeta_all{j, ih};
            mM_j = sPre.mMDesign_all{j, ih};
            mSigmaPair = (mSigma_i + sPre.mSigma_all{j, ih}) / 2;
            mInvSqrt = inverse_symmetric_sqrt(mSigmaPair);
            sPre.mDelta_all{i, j, ih} = mBeta_i - mBeta_j;

            for m = reshape(vValidLocations, 1, [])
                vBeta_i = mBeta_i(m, :)';
                vBeta_j = mBeta_j(m, :)';
                mM_i_m = reshape(mM_i(m, :, :), [K, K]);
                mM_j_m = reshape(mM_j(m, :, :), [K, K]);
                if any(~isfinite([vBeta_i; vBeta_j; mM_i_m(:); mM_j_m(:)]))
                    continue;
                end
                vScoreDifference = sqrt(T * dH) * ...
                    (mM_i_m * vBeta_i - mM_j_m * vBeta_j);
                dStatistic = max(abs(mInvSqrt * vScoreDifference)) - vLambda(ih);
                sPre.mS(i, j, m, ih) = dStatistic;
                sPre.mS(j, i, m, ih) = dStatistic;
            end
        end
    end
end

end

function sInfo = summarize_legacy_hac(cSigma, mBandwidth, sScoreMode)
[N, nH] = size(cSigma);
vTrace = nan(N * nH, 1);
vMinimumEigenvalue = nan(N * nH, 1);
iRow = 0;
for ih = 1:nH
    for i = 1:N
        iRow = iRow + 1;
        mSigma_i = cSigma{i, ih};
        vTrace(iRow) = trace(mSigma_i);
        vMinimumEigenvalue(iRow) = min(real(eig((mSigma_i + mSigma_i') / 2)));
    end
end
sInfo = struct();
sInfo.scoreMode = string(sScoreMode);
sInfo.regressorLayout = "unspecified";
sInfo.pilotBandwidth = NaN;
sInfo.meanLeverage = NaN;
sInfo.maxLeverage = NaN;
sInfo.meanRawResidualVariance = NaN;
sInfo.meanCorrectedResidualVariance = NaN;
sInfo.numPairCovariances = 0;
sInfo.pooledHomogeneous = false;
sInfo.meanCovarianceTrace = mean(vTrace);
sInfo.minimumCovarianceEigenvalue = min(vMinimumEigenvalue);
sInfo.meanHACBandwidth = mean(mBandwidth(:));
end

function bCommon = regressors_are_common(mX, sHAC)
if isfield(sHAC, 'commonRegressorTolerance') && ...
        ~isempty(sHAC.commonRegressorTolerance)
    dTolerance = sHAC.commonRegressorTolerance;
else
    dTolerance = 1e-12;
end

[N, T, K] = size(mX);
mXCommon = reshape(mX(1, :, :), [T, K]);
bCommon = true;
for i = 2:N
    mX_i = reshape(mX(i, :, :), [T, K]);
    if max(abs(mX_i(:) - mXCommon(:))) > dTolerance
        bCommon = false;
        return;
    end
end
end

function mBetaAtTime = interpolate_beta_path(vU, mBeta, vTime)
K = size(mBeta, 2);
mBetaAtTime = nan(length(vTime), K);
for k = 1:K
    vValid = isfinite(mBeta(:, k));
    if nnz(vValid) < 2
        error('Insufficient valid local coefficient estimates for HAC residuals.');
    end
    mBetaAtTime(:, k) = interp1(vU(vValid), mBeta(vValid, k), ...
        vTime, 'linear', 'extrap');
end
end

function mInvSqrt = inverse_symmetric_sqrt(mA)
mA = (mA + mA') / 2;
[mEigenvectors, vEigenvalues] = eig(mA, 'vector');
dFloor = max(1e-12, 1e-10 * max(abs(vEigenvalues)));
vEigenvalues = max(real(vEigenvalues), dFloor);
mInvSqrt = real(mEigenvectors * diag(1 ./ sqrt(vEigenvalues)) * mEigenvectors');
end
