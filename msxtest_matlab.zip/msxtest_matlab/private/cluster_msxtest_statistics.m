function sCluster = cluster_msxtest_statistics(mS, dCriticalValue, iFixedGroups, iMaximumGroups)

if nargin < 3
    iFixedGroups = 2;
end
if nargin < 4 || isempty(iMaximumGroups)
    iMaximumGroups = size(mS, 1);
end

N = size(mS, 1);
iMaximumGroups = min(max(round(iMaximumGroups), 1), N);
mDissimilarity = zeros(N, N);
for i = 1:N - 1
    for j = i + 1:N
        vPairStatistics = reshape(mS(i, j, :, :), [], 1);
        vPairStatistics = vPairStatistics(isfinite(vPairStatistics));
        if isempty(vPairStatistics)
            dDistance = -inf;
        else
            dDistance = max(vPairStatistics);
        end
        mDissimilarity(i, j) = dDistance;
        mDissimilarity(j, i) = dDistance;
    end
end

vOffDiagonal = mDissimilarity(~eye(N));
vFinite = vOffDiagonal(isfinite(vOffDiagonal));
if isempty(vFinite)
    error('No finite pairwise statistics are available for clustering.');
end
mDissimilarity(~isfinite(mDissimilarity)) = min(vFinite);

dShift = max(0, -min(vFinite));
mLinkageDistance = mDissimilarity + dShift;
mLinkageDistance(1:N + 1:end) = 0;
Z = linkage(squareform(mLinkageDistance), 'complete');

iFixedGroups = min(max(round(iFixedGroups), 1), N);
vFixedCluster = cluster(Z, 'maxclust', iFixedGroups);

iEstimatedGroups = iMaximumGroups;
vEstimatedCluster = cluster(Z, 'maxclust', iMaximumGroups);
for iGroups = 1:iMaximumGroups
    vCandidate = cluster(Z, 'maxclust', iGroups);
    dMaxWithin = maximum_within_cluster(mDissimilarity, vCandidate);
    if dMaxWithin <= dCriticalValue
        iEstimatedGroups = numel(unique(vCandidate));
        vEstimatedCluster = vCandidate;
        break;
    end
end

sCluster.mDissimilarity = mDissimilarity;
sCluster.dLinkageShift = dShift;
sCluster.Z = Z;
sCluster.iFixedGroups = iFixedGroups;
sCluster.vFixedCluster = vFixedCluster;
sCluster.iMaximumGroups = iMaximumGroups;
sCluster.iEstimatedGroups = iEstimatedGroups;
sCluster.vEstimatedCluster = vEstimatedCluster;

end

function dMaximum = maximum_within_cluster(mDissimilarity, vCluster)
dMaximum = -inf;
vGroups = unique(vCluster(:))';
for iGroup = vGroups
    vMembers = find(vCluster == iGroup);
    if numel(vMembers) < 2
        continue;
    end
    mWithin = mDissimilarity(vMembers, vMembers);
    vWithin = mWithin(triu(true(numel(vMembers)), 1));
    dMaximum = max(dMaximum, max(vWithin));
end
end
