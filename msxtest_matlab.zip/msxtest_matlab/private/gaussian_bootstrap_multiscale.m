function [vW_multi_boot, vCritValues_multi, mW_boot_by_h, mCritValues_by_h] = ...
    gaussian_bootstrap_multiscale(mY, mX, vH, vU, iB, vAlpha, sPre, mAdmissible)

[N, T, K] = size(mX);
vH = vH(:);
vU = vU(:);
vAlpha = vAlpha(:);
nH = length(vH);
M = length(vU);

if nargin < 8 || isempty(mAdmissible)
    mAdmissible = vU >= vH' & vU <= (1 - vH');
end
if ~isequal(size(mAdmissible), [M, nH])
    error('mAdmissible must have size length(vU)-by-length(vH).');
end

if nargin >= 7 && ~isempty(sPre) && isfield(sPre, 'mKernel_all')
    cKernel = sPre.mKernel_all;
elseif nargin >= 7 && ~isempty(sPre) && isfield(sPre, 'cKernelRaw')
    cKernel = sPre.cKernelRaw;
else
    vTime = (1:T)' / T;
    cKernel = cell(nH, 1);
    for ih = 1:nH
        cKernel{ih} = epanechnikov_kernel((vTime - vU') / vH(ih));
    end
end

vLambda = sqrt(2 * log(1 ./ (2 * vH)));
vW_multi_boot = -inf(iB, 1);
mW_boot_by_h = -inf(iB, nH);

iBatchSize = min(50, iB);
for iBatchStart = 1:iBatchSize:iB
    iBatchEnd = min(iBatchStart + iBatchSize - 1, iB);
    iBatchCount = iBatchEnd - iBatchStart + 1;
    mBatchMaximum = -inf(iBatchCount, nH);

    cGaussianByCoordinate = cell(K, 1);
    for k = 1:K
        cGaussianByCoordinate{k} = randn(N * iBatchCount, T);
    end

    for ih = 1:nH
        dH = vH(ih);
        mKernelRaw = cKernel{ih};
        if nargin >= 7 && ~isempty(sPre) && isfield(sPre, 'mKernel_all')
            mKernelRaw = mKernelRaw * dH;
        end
        dScale = sqrt(T * dH);
        vValidLocations = find(mAdmissible(:, ih));
        if isempty(vValidLocations)
            continue;
        end

        vMaxAtH = -inf(iBatchCount, 1);
        for k = 1:K
            mLocal = (cGaussianByCoordinate{k} * mKernelRaw(:, vValidLocations)) / dScale;
            aLocal = reshape(mLocal, [N, iBatchCount, length(vValidLocations)]);
            mPairMaximum = squeeze(max(aLocal, [], 1) - min(aLocal, [], 1));
            if iBatchCount == 1
                mPairMaximum = reshape(mPairMaximum, [1, length(vValidLocations)]);
            end
            vMaxAtH = max(vMaxAtH, max(mPairMaximum, [], 2) - vLambda(ih));
        end
        mBatchMaximum(:, ih) = vMaxAtH;
    end

    mW_boot_by_h(iBatchStart:iBatchEnd, :) = mBatchMaximum;
    vW_multi_boot(iBatchStart:iBatchEnd) = max(mBatchMaximum, [], 2);
end

L = length(vAlpha);
vCritValues_multi = zeros(L, 1);
mCritValues_by_h = zeros(nH, L);

for l = 1:L
    vCritValues_multi(l) = quantile(vW_multi_boot, 1 - vAlpha(l));
    for ih = 1:nH
        mCritValues_by_h(ih, l) = quantile(mW_boot_by_h(:, ih), 1 - vAlpha(l));
    end
end

end
