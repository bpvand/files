function [u,h,info] = msxtest_grid(T,g)
switch lower(string(g.mode))
    case "paper", lowerBound = T^(-1/3);
    case {"kv","khismatullina-vogt"}, lowerBound = log(T)/T;
    otherwise, error('msxtest:Grid','grid.mode must be paper or kv.');
end
if ~isempty(g.minimumBandwidth)
    validateattributes(g.minimumBandwidth,{'numeric'},{'scalar','real','finite','>',0,'<=',0.5});
    lowerBound = g.minimumBandwidth;
end
validateattributes(g.maximumBandwidth,{'numeric'},{'scalar','real','finite','>',0,'<=',0.5});
switch lower(string(g.latticeMode))
    case "paper-empirical", spacing = [5,0,5,-3];
    case "full", spacing = [1,0,1,0];
    case "kv-2020", spacing = [5,0,5,0];
    case "kv-quarterly", spacing = [4,0.5,4,0];
    case "custom"
        spacing = [g.locationStep,g.locationOffset,g.bandwidthStep,g.bandwidthOffset];
    otherwise, error('msxtest:Grid','Unknown grid.latticeMode.');
end
validateattributes(spacing,{'numeric'},{'vector','numel',4,'real','finite'});
assert(spacing(1)>0 && spacing(3)>0,'msxtest:Grid','Grid steps must be positive.');
if isempty(g.locations)
    indices = 1:ceil((T-spacing(2))/spacing(1));
    u = ((spacing(1)*indices+spacing(2))/T)';
    u = u(u>=0 & u<=1);
else
    validateattributes(g.locations,{'numeric'},{'vector','nonempty','real','finite','>=',0,'<=',1});
    u = unique(g.locations(:));
end
if isempty(g.bandwidths)
    indices = 1:ceil((T*g.maximumBandwidth-spacing(4))/spacing(3));
    h = ((spacing(3)*indices+spacing(4))/T)';
    h = h(h>=lowerBound & h<=g.maximumBandwidth & h>0);
else
    validateattributes(g.bandwidths,{'numeric'},{'vector','nonempty','real','finite','>',0,'<=',0.5});
    h = unique(g.bandwidths(:));
end
assert(~isempty(u) && ~isempty(h),'msxtest:Grid', ...
    'Empty grid. Use mode=kv, change bandwidth bounds, or supply grid.bandwidths.');
mask = u>=h' & u<=(1-h');
assert(any(mask(:)),'msxtest:Grid','No intervals lie entirely within [0,1].');
info = struct('locations',u,'bandwidths',h,'admissible',mask, ...
    'testedIntervals',nnz(mask),'minimumBandwidth',min(h),'maximumBandwidth',max(h));
end
