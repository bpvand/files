function [dMaximum, sMaximum] = compute_a12_design_diagnostic(sPre)

N = sPre.N;
K = sPre.K;
dMaximum = -inf;
sMaximum = struct('unitI', NaN, 'unitJ', NaN, 'u', NaN, 'h', NaN, ...
    'scaledMaximum', NaN);

for ih = 1:sPre.nH
    dH = sPre.vH(ih);
    dPaperScale = sqrt(sPre.T * dH);
    vValidLocations = find(sPre.mAdmissible(:, ih));

    for i = 1:N - 1
        mM_i = sPre.mMDesign_all{i, ih};
        mSigma_i = sPre.mSigma_all{i, ih};
        for j = i + 1:N
            mM_j = sPre.mMDesign_all{j, ih};
            mSigmaPair = (mSigma_i + sPre.mSigma_all{j, ih}) / 2;
            mInvSqrt = inverse_symmetric_sqrt(mSigmaPair);

            for m = reshape(vValidLocations, 1, [])
                mDesignDifference = dPaperScale * ( ...
                    reshape(mM_i(m, :, :), [K, K]) - ...
                    reshape(mM_j(m, :, :), [K, K]));
                if any(~isfinite(mDesignDifference(:)))
                    continue;
                end
                dValue = norm(mInvSqrt * mDesignDifference, inf);
                if dValue > dMaximum
                    dMaximum = dValue;
                    sMaximum.unitI = i;
                    sMaximum.unitJ = j;
                    sMaximum.u = sPre.vU(m);
                    sMaximum.h = dH;
                end
            end
        end
    end
end

if ~isfinite(dMaximum)
    dMaximum = NaN;
end
sMaximum.scaledMaximum = sqrt(log(sPre.T)) * dMaximum;

end

function mInvSqrt = inverse_symmetric_sqrt(mA)
mA = (mA + mA') / 2;
[mEigenvectors, vEigenvalues] = eig(mA, 'vector');
dFloor = max(1e-12, 1e-10 * max(abs(vEigenvalues)));
vEigenvalues = max(real(vEigenvalues), dFloor);
mInvSqrt = real(mEigenvectors * diag(1 ./ sqrt(vEigenvalues)) * mEigenvectors');
end
