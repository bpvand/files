function [aSigma, mBandwidth, sInfo] = estimate_individual_regressor_hac( ...
    mYDemeaned, mX, vH, sHAC)

if nargin < 4
    sHAC = struct();
end
sHAC = fill_defaults(sHAC);

[N, T] = size(mYDemeaned);
if size(mX, 1) ~= N || size(mX, 2) ~= T
    error('mYDemeaned and mX have incompatible dimensions.');
end
[~, ~, K] = size(mX);

if ~ismember(lower(sHAC.scoreMode), {'pilot-loo', 'pilot-in-sample'})
    error(['Individual-regressor HAC supports ''pilot-loo'' and ' ...
        '''pilot-in-sample'', not ''%s''.'], sHAC.scoreMode);
end

dPilotH = resolve_pilot_bandwidth(vH, sHAC, T);
aSigmaUnit = nan(N, K, K);
vBandwidth = nan(N, 1);
mLeverage = nan(N, T);
mRawResidual = nan(N, T);
mResidual = nan(N, T);

for i = 1:N
    mX_i = reshape(mX(i, :, :), [T, K]);
    [mSmoother_i, vLeverage_i] = local_constant_smoother(mX_i, dPilotH);
    vRawResidual_i = mYDemeaned(i, :)' - mSmoother_i * mYDemeaned(i, :)';
    vResidual_i = vRawResidual_i;

    if strcmpi(sHAC.scoreMode, 'pilot-loo')
        vDenominator = max(1 - vLeverage_i, sHAC.minimumLOODenominator);
        vResidual_i = vRawResidual_i ./ vDenominator;
    end

    [mSigma_i, vBandwidth(i)] = ...
        estimate_bartlett_hac(mX_i .* vResidual_i, sHAC);
    aSigmaUnit(i, :, :) = reshape(mSigma_i, [1, K, K]);
    mLeverage(i, :) = vLeverage_i';
    mRawResidual(i, :) = vRawResidual_i';
    mResidual(i, :) = vResidual_i';
end

if sHAC.poolHomogeneous
    mPooledSigma = regularize_covariance(squeeze(mean(aSigmaUnit, 1)));
    for i = 1:N
        aSigmaUnit(i, :, :) = reshape(mPooledSigma, [1, K, K]);
    end
end

nH = length(vH);
aSigma = repmat(aSigmaUnit, [1, 1, 1, nH]);
mBandwidth = repmat(vBandwidth, [1, nH]);

sInfo = struct();
sInfo.scoreMode = string(sHAC.scoreMode);
sInfo.regressorLayout = "individual";
sInfo.pilotBandwidth = dPilotH;
sInfo.meanLeverage = mean(mLeverage(:));
sInfo.maxLeverage = max(mLeverage(:));
sInfo.meanRawResidualVariance = mean(mRawResidual(:).^2);
sInfo.meanCorrectedResidualVariance = mean(mResidual(:).^2);
sInfo.numPairCovariances = 0;
sInfo.pooledHomogeneous = logical(sHAC.poolHomogeneous);
sInfo.meanCovarianceTrace = mean_covariance_trace(aSigmaUnit);
sInfo.minimumCovarianceEigenvalue = minimum_covariance_eigenvalue(aSigmaUnit);
sInfo.meanHACBandwidth = mean(vBandwidth);

end

function sHAC = fill_defaults(sHAC)
if ~isfield(sHAC, 'bandwidthMode') || isempty(sHAC.bandwidthMode)
    sHAC.bandwidthMode = 'andrews-ar1';
end
if ~isfield(sHAC, 'fixedBandwidth')
    sHAC.fixedBandwidth = [];
end
if ~isfield(sHAC, 'finiteSampleCorrection')
    sHAC.finiteSampleCorrection = true;
end
if ~isfield(sHAC, 'scoreMode') || isempty(sHAC.scoreMode)
    sHAC.scoreMode = 'pilot-in-sample';
end
if ~isfield(sHAC, 'pilotBandwidthMode') || isempty(sHAC.pilotBandwidthMode)
    sHAC.pilotBandwidthMode = 'smallest-grid';
end
if ~isfield(sHAC, 'pilotBandwidth')
    sHAC.pilotBandwidth = [];
end
if ~isfield(sHAC, 'minimumLOODenominator') || isempty(sHAC.minimumLOODenominator)
    sHAC.minimumLOODenominator = 0.10;
end
if ~isfield(sHAC, 'poolHomogeneous')
    sHAC.poolHomogeneous = true;
end
end

function dPilotH = resolve_pilot_bandwidth(vH, sHAC, T)
switch lower(sHAC.pilotBandwidthMode)
    case 't-one-third'
        dPilotH = T^(-1/3);
    case 'smallest-grid'
        dPilotH = min(vH);
    case 'largest-grid'
        dPilotH = max(vH);
    case 'fixed'
        if isempty(sHAC.pilotBandwidth) || sHAC.pilotBandwidth <= 0
            error('A positive pilotBandwidth is required for fixed pilot bandwidths.');
        end
        dPilotH = sHAC.pilotBandwidth;
    case 't-one-fifth'
        dPilotH = T^(-1/5);
    otherwise
        error('Unknown pilot bandwidth mode: %s', sHAC.pilotBandwidthMode);
end
end

function [mSmoother, vLeverage] = local_constant_smoother(mX, dH)
[T, ~] = size(mX);
vTime = (1:T)' / T;
mKernel = epanechnikov_kernel((vTime - vTime') / dH);
mSmoother = zeros(T, T);
vLeverage = zeros(T, 1);

for t = 1:T
    vWeight = mKernel(:, t);
    mCrossProduct = mX' * (mX .* vWeight);
    if rcond(mCrossProduct) < 1e-12
        error('Pilot local design is singular for a unit at time index %d.', t);
    end
    vProjection = mCrossProduct \ mX(t, :)';
    mSmoother(t, :) = (vWeight .* (mX * vProjection))';
    vLeverage(t) = mSmoother(t, t);
end
end

function mA = regularize_covariance(mA)
mA = (mA + mA') / 2;
[mEigenvectors, vEigenvalues] = eig(mA, 'vector');
dFloor = max(1e-12, 1e-10 * max(abs(vEigenvalues)));
vEigenvalues = max(real(vEigenvalues), dFloor);
mA = real(mEigenvectors * diag(vEigenvalues) * mEigenvectors');
end

function dMeanTrace = mean_covariance_trace(aSigma)
N = size(aSigma, 1);
vTrace = nan(N, 1);
for i = 1:N
    vTrace(i) = trace(squeeze(aSigma(i, :, :)));
end
dMeanTrace = mean(vTrace);
end

function dMinimum = minimum_covariance_eigenvalue(aSigma)
N = size(aSigma, 1);
dMinimum = inf;
for i = 1:N
    mSigma_i = squeeze(aSigma(i, :, :));
    dMinimum = min(dMinimum, min(real(eig((mSigma_i + mSigma_i') / 2))));
end
end
