function [mLongRunCov, dBandwidth] = estimate_bartlett_hac(mV, sOptions)

if nargin < 2
    sOptions = struct();
end
if ~isfield(sOptions, 'bandwidthMode')
    sOptions.bandwidthMode = 'andrews-ar1';
end
if ~isfield(sOptions, 'fixedBandwidth')
    sOptions.fixedBandwidth = [];
end
if ~isfield(sOptions, 'finiteSampleCorrection')
    sOptions.finiteSampleCorrection = true;
end

[T, K] = size(mV);

switch lower(sOptions.bandwidthMode)
    case 'andrews-ar1'
        dBandwidth = andrews_ar1_bandwidth(mV - mean(mV, 1));
    case 't-one-third'
        dBandwidth = T^(1/3);
    case 'fixed'
        if isempty(sOptions.fixedBandwidth) || sOptions.fixedBandwidth <= 0
            error('A positive fixedBandwidth is required for fixed HAC bandwidths.');
        end
        dBandwidth = sOptions.fixedBandwidth;
    otherwise
        error('Unknown HAC bandwidth mode: %s', sOptions.bandwidthMode);
end

if ~isfinite(dBandwidth) || dBandwidth <= 0
    dBandwidth = T^(1/3);
end

mLongRunCov = (mV' * mV) / T;
iMaxLag = min(T - 1, floor(dBandwidth));
for iLag = 1:iMaxLag
    dWeight = 1 - iLag / dBandwidth;
    if dWeight <= 0
        continue;
    end
    mLagCov = (mV(1 + iLag:T, :)' * mV(1:T - iLag, :)) / T;
    mLongRunCov = mLongRunCov + dWeight * (mLagCov + mLagCov');
end

if sOptions.finiteSampleCorrection && T > K
    mLongRunCov = (T / (T - K)) * mLongRunCov;
end

mLongRunCov = (mLongRunCov + mLongRunCov') / 2;
[mEigenvectors, mEigenvalues] = eig(mLongRunCov, 'vector');
dFloor = max(1e-12, 1e-10 * max(abs(mEigenvalues)));
mEigenvalues = max(real(mEigenvalues), dFloor);
mLongRunCov = real(mEigenvectors * diag(mEigenvalues) * mEigenvectors');

end

function dBandwidth = andrews_ar1_bandwidth(mV)

[T, K] = size(mV);
vRho = zeros(K, 1);
vInnovationVariance = zeros(K, 1);

for k = 1:K
    vLag = mV(1:T - 1, k);
    vLead = mV(2:T, k);
    dDenominator = vLag' * vLag;
    if dDenominator <= eps
        continue;
    end
    vRho(k) = max(-0.99, min(0.99, (vLag' * vLead) / dDenominator));
    vResidual = vLead - vRho(k) * vLag;
    vInnovationVariance(k) = (vResidual' * vResidual) / max(T - 1, 1);
end

vNumerator0 = 4 * (vRho .^ 2) .* (vInnovationVariance .^ 2);
vDenominator0 = (vInnovationVariance .^ 2) ./ ((1 - vRho) .^ 4);
vNumerator1 = ((1 - vRho) .^ 6) .* ((1 + vRho) .^ 2);
dDenominatorSum = sum(vDenominator0);

if dDenominatorSum <= eps
    dBandwidth = T^(1/3);
    return;
end

dAlpha1 = sum(vNumerator0 ./ max(vNumerator1, eps)) / dDenominatorSum;
dBandwidth = 1.1447 * (max(dAlpha1, eps) * T)^(1/3);

end
