function plot_msxtest_clusters(result,units,regressors,directory)
c = result.clustering;
fig = figure('Visible','off','Color','w','Position',[100,100,1200,600]);
closer = onCleanup(@() close(fig));
dendrogram(c.linkage,0,'Labels',cellstr(units));
yline(c.criticalValue+c.linkageShift,'--r','Global critical value');
xtickangle(60); ylabel('Dissimilarity (shifted for plotting)');
title(sprintf('Complete linkage: %d estimated groups; fixed comparison: %d groups', ...
    c.estimatedGroups,c.fixedGroups));
exportgraphics(fig,fullfile(directory,'clustering_dendrogram.png'),'Resolution',160);
fig2 = figure('Visible','off','Color','w','Position',[100,100,1250,360*numel(regressors)]);
closer2 = onCleanup(@() close(fig2));
layout = tiledlayout(fig2,numel(regressors),2,'TileSpacing','compact');
valid = result.grid.admissible(:,1);
for k=1:numel(regressors)
    for mode=1:2
        ax = nexttile(layout); hold(ax,'on');
        if mode==1
            assignment = result.clusters.EstimatedCluster; count = c.estimatedGroups;
            heading = sprintf('Estimated K = %d',count);
        else
            assignment = result.clusters.FixedCluster; count = c.actualFixedGroups;
            heading = sprintf('Fixed K = %d',count);
            if count~=c.fixedGroups
                heading = sprintf('Fixed K requested = %d; returned = %d',c.fixedGroups,count);
            end
        end
        colors = lines(count); handles = gobjects(count,1);
        for i=1:numel(units)
            beta = reshape(result.coefficientEstimates(i,:,k,1),[],1);
            beta(~valid) = NaN;
            handles(assignment(i)) = plot(ax,result.grid.locations,beta, ...
                'Color',colors(assignment(i),:),'LineWidth',1);
        end
        title(ax,regressors(k)+": "+heading,'Interpreter','none','FontWeight','normal');
        ylabel(ax,'Estimated coefficient'); xlabel(ax,'Normalized time'); grid(ax,'on');
        if count<=12
            legend(ax,handles,"Group "+string((1:count)'), ...
                'Location','best','Interpreter','none');
        end
    end
end
exportgraphics(fig2,fullfile(directory,'coefficients_by_cluster.png'),'Resolution',160);
end
