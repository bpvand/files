function [aSigma, mBandwidth, sInfo] = estimate_common_regressor_hac( ...
    mYDemeaned, mX, vH, sHAC)

if nargin < 4
    sHAC = struct();
end
sHAC = fill_defaults(sHAC);

[N, T] = size(mYDemeaned);
if size(mX, 1) == N && size(mX, 2) == T
    [~, ~, K] = size(mX);
    mXCommon = reshape(mX(1, :, :), [T, K]);
    for i = 2:N
        mX_i = reshape(mX(i, :, :), [T, K]);
        if max(abs(mX_i(:) - mXCommon(:))) > sHAC.commonRegressorTolerance
            error(['HAC score mode ''%s'' requires X_it=X_t. ' ...
                'Use ''legacy-in-sample'' or a design-aware test for individual regressors.'], ...
                sHAC.scoreMode);
        end
    end
elseif size(mX, 1) == T
    [~, K] = size(mX);
    mXCommon = mX;
else
    error('mYDemeaned and mX have incompatible dimensions.');
end

aSigmaUnit = nan(N, K, K);
vBandwidth = nan(N, 1);
sInfo = struct();
sInfo.scoreMode = string(sHAC.scoreMode);
sInfo.regressorLayout = "common";
sInfo.pilotBandwidth = NaN;
sInfo.meanLeverage = NaN;
sInfo.maxLeverage = NaN;
sInfo.meanRawResidualVariance = NaN;
sInfo.meanCorrectedResidualVariance = NaN;
sInfo.numPairCovariances = 0;
sInfo.pooledHomogeneous = logical(sHAC.poolHomogeneous);

switch lower(sHAC.scoreMode)
    case {'pilot-loo', 'pilot-in-sample'}
        dPilotH = resolve_pilot_bandwidth(vH, sHAC, T);
        [mSmoother, vLeverage] = local_constant_smoother(mXCommon, dPilotH);
        mFitted = (mSmoother * mYDemeaned')';
        mRawResidual = mYDemeaned - mFitted;
        mResidual = mRawResidual;

        if strcmpi(sHAC.scoreMode, 'pilot-loo')
            vDenominator = max(1 - vLeverage, sHAC.minimumLOODenominator);
            mResidual = mRawResidual ./ vDenominator';
        end

        for i = 1:N
            mScore = mXCommon .* mResidual(i, :)';
            [mSigma_i, vBandwidth(i)] = estimate_bartlett_hac(mScore, sHAC);
            aSigmaUnit(i, :, :) = reshape(mSigma_i, [1, K, K]);
        end

        sInfo.pilotBandwidth = dPilotH;
        sInfo.meanLeverage = mean(vLeverage);
        sInfo.maxLeverage = max(vLeverage);
        sInfo.meanRawResidualVariance = mean(mRawResidual(:).^2);
        sInfo.meanCorrectedResidualVariance = mean(mResidual(:).^2);

    case 'pair-difference'
        if N < 2
            error('Pair-difference HAC requires at least two units.');
        end
        iPairCount = N * (N - 1) / 2;
        if strcmpi(sHAC.bandwidthMode, 'andrews-ar1')
            aPairSigma = nan(iPairCount, K, K);
            vPairBandwidth = nan(iPairCount, 1);
            iPair = 0;
            for i = 1:N - 1
                for j = i + 1:N
                    iPair = iPair + 1;
                    vOutcomeDifference = (mYDemeaned(i, :) - mYDemeaned(j, :))';
                    mPairScore = mXCommon .* vOutcomeDifference;
                    [mPairLongRunCov, vPairBandwidth(iPair)] = ...
                        estimate_bartlett_hac(mPairScore, sHAC);
                    aPairSigma(iPair, :, :) = ...
                        reshape(mPairLongRunCov / 2, [1, K, K]);
                end
            end
            mPooledSigma = squeeze(mean(aPairSigma, 1));
            dMeanBandwidth = mean(vPairBandwidth);
        else
            mCrossSectionMean = mean(mYDemeaned, 1);
            mPooledSigma = zeros(K, K);
            vCenteredBandwidth = nan(N, 1);
            for i = 1:N
                vCenteredOutcome = (mYDemeaned(i, :) - mCrossSectionMean)';
                mCenteredScore = mXCommon .* vCenteredOutcome;
                [mCenteredSigma, vCenteredBandwidth(i)] = ...
                    estimate_bartlett_hac(mCenteredScore, sHAC);
                mPooledSigma = mPooledSigma + mCenteredSigma / (N - 1);
            end
            dMeanBandwidth = mean(vCenteredBandwidth);
        end
        mPooledSigma = regularize_covariance(mPooledSigma);
        for i = 1:N
            aSigmaUnit(i, :, :) = reshape(mPooledSigma, [1, K, K]);
        end
        vBandwidth(:) = dMeanBandwidth;
        sInfo.numPairCovariances = iPairCount;
        sInfo.pooledHomogeneous = true;

    otherwise
        error('Unknown common-regressor HAC score mode: %s', sHAC.scoreMode);
end

if sHAC.poolHomogeneous && ~strcmpi(sHAC.scoreMode, 'pair-difference')
    mPooledSigma = squeeze(mean(aSigmaUnit, 1));
    mPooledSigma = regularize_covariance(mPooledSigma);
    for i = 1:N
        aSigmaUnit(i, :, :) = reshape(mPooledSigma, [1, K, K]);
    end
end

nH = length(vH);
aSigma = repmat(aSigmaUnit, [1, 1, 1, nH]);
mBandwidth = repmat(vBandwidth, [1, nH]);
sInfo.meanCovarianceTrace = mean_covariance_trace(aSigmaUnit);
sInfo.minimumCovarianceEigenvalue = minimum_covariance_eigenvalue(aSigmaUnit);
sInfo.meanHACBandwidth = mean(vBandwidth);

end

function sHAC = fill_defaults(sHAC)
if ~isfield(sHAC, 'bandwidthMode') || isempty(sHAC.bandwidthMode)
    sHAC.bandwidthMode = 'andrews-ar1';
end
if ~isfield(sHAC, 'fixedBandwidth')
    sHAC.fixedBandwidth = [];
end
if ~isfield(sHAC, 'finiteSampleCorrection')
    sHAC.finiteSampleCorrection = true;
end
if ~isfield(sHAC, 'scoreMode') || isempty(sHAC.scoreMode)
    sHAC.scoreMode = 'pilot-in-sample';
end
if ~isfield(sHAC, 'pilotBandwidthMode') || isempty(sHAC.pilotBandwidthMode)
    sHAC.pilotBandwidthMode = 'smallest-grid';
end
if ~isfield(sHAC, 'pilotBandwidth')
    sHAC.pilotBandwidth = [];
end
if ~isfield(sHAC, 'minimumLOODenominator') || isempty(sHAC.minimumLOODenominator)
    sHAC.minimumLOODenominator = 0.10;
end
if ~isfield(sHAC, 'poolHomogeneous')
    sHAC.poolHomogeneous = true;
end
if ~isfield(sHAC, 'commonRegressorTolerance') || isempty(sHAC.commonRegressorTolerance)
    sHAC.commonRegressorTolerance = 1e-12;
end
end

function dPilotH = resolve_pilot_bandwidth(vH, sHAC, T)
switch lower(sHAC.pilotBandwidthMode)
    case 't-one-third'
        dPilotH = T^(-1/3);
    case 'smallest-grid'
        dPilotH = min(vH);
    case 'largest-grid'
        dPilotH = max(vH);
    case 'fixed'
        if isempty(sHAC.pilotBandwidth) || sHAC.pilotBandwidth <= 0
            error('A positive pilotBandwidth is required for fixed pilot bandwidths.');
        end
        dPilotH = sHAC.pilotBandwidth;
    case 't-one-fifth'
        dPilotH = T^(-1/5);
    otherwise
        error('Unknown pilot bandwidth mode: %s', sHAC.pilotBandwidthMode);
end
end

function [mSmoother, vLeverage] = local_constant_smoother(mX, dH)
[T, ~] = size(mX);
vTime = (1:T)' / T;
mKernel = epanechnikov_kernel((vTime - vTime') / dH);
mSmoother = zeros(T, T);
vLeverage = zeros(T, 1);

for t = 1:T
    vWeight = mKernel(:, t);
    mCrossProduct = mX' * (mX .* vWeight);
    if rcond(mCrossProduct) < 1e-12
        error('Pilot local design is singular at time index %d.', t);
    end
    vProjection = mCrossProduct \ mX(t, :)';
    mSmoother(t, :) = (vWeight .* (mX * vProjection))';
    vLeverage(t) = mSmoother(t, t);
end
end

function mA = regularize_covariance(mA)
mA = (mA + mA') / 2;
[mEigenvectors, vEigenvalues] = eig(mA, 'vector');
dFloor = max(1e-12, 1e-10 * max(abs(vEigenvalues)));
vEigenvalues = max(real(vEigenvalues), dFloor);
mA = real(mEigenvectors * diag(vEigenvalues) * mEigenvectors');
end

function dMeanTrace = mean_covariance_trace(aSigma)
N = size(aSigma, 1);
vTrace = nan(N, 1);
for i = 1:N
    vTrace(i) = trace(squeeze(aSigma(i, :, :)));
end
dMeanTrace = mean(vTrace);
end

function dMinimum = minimum_covariance_eigenvalue(aSigma)
N = size(aSigma, 1);
dMinimum = inf;
for i = 1:N
    mSigma_i = squeeze(aSigma(i, :, :));
    dMinimum = min(dMinimum, min(real(eig((mSigma_i + mSigma_i') / 2))));
end
end
