function vK = epanechnikov_kernel(vU)

vK = 0.75 * (1 - vU.^2) .* (abs(vU) <= 1);

end
