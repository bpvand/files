function result = example_msxtest()
% A self-contained example with four units and two regressors.
before = rng;
restoreRNG = onCleanup(@() rng(before));
rng(321,'twister');
T = 200; N = 4;
u = (1:T)'/T;
X = randn(T,2);
beta1 = 0.8+0.2*sin(2*pi*u);
beta2 = 0.4+0.1*cos(2*pi*u);
Y = X(:,1).*beta1+X(:,2).*beta2+0.25*randn(T,N);
Y(:,2) = Y(:,2)+X(:,1).*exp(-0.5*((u-0.5)/0.08).^2);
o = msxtest_options();
o.unitNames = ["Unit A","Unit B","Unit C","Unit D"];
o.regressorNames = ["Regressor 1","Regressor 2"];
o.clustering.enabled = true;
result = msxtest(Y,X,o);
[fig,result.rejectionPeriods] = plot_msxtest_diagnostics(result,"Unit B");
close(fig);
writematrix(Y,fullfile(result.outputDirectory,'example_outcomes.csv'));
writematrix(X,fullfile(result.outputDirectory,'example_regressors.csv'));
end
